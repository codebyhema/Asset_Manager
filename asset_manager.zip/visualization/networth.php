<div class="networth-container">
    <div class="heading">
        <h1>Comprehensive Net Worth Overview</h1>
        <h2> Analyzing Your Financial Position</h2>
    </div>
    <div class="net-content"></div>
   </div>